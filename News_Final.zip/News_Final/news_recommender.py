import streamlit as st
import requests
import re
import sqlite3
from googlesearch import search
from datetime import datetime
from collections import defaultdict
import csv
import os
import pandas as pd
import joblib
from fuzzywuzzy import process
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from huggingface_hub import InferenceClient
from datetime import datetime
import re
import numpy as np
from utils import debounce_replicate_run

# Load data
news = pd.read_json("Data/news.json", lines=True)

st.set_page_config(page_title="News Recommender", page_icon="🤖", layout="wide", )

# 🔧 Hardcoded values for your API token and model endpoints
REPLICATE_API_TOKEN = 'r8_98P5PK8tCRD31YoHd9B01AKHSG8fIGR4Zy7f5'
LLaMA2_7B_ENDPOINT = 'a16z-infra/llama7b-v2-chat:4f0a4744c7295c024a1de15e1a63c880d3da035fa1f49bfd344fe076074c8eea'
LLaMA2_13B_ENDPOINT = 'a16z-infra/llama13b-v2-chat:df7690f1994d94e96ad9d568eac121aecf50684a0b0963b25a41cc40061269e5'
LLaMA2_70B_ENDPOINT = 'replicate/llama70b-v2-chat:e951f18578850b652510200860fc4ea62b3b16fac280f83ff32282f87bbd2e48'

PRE_PROMPT = "You are a helpful assistant. You do not respond as 'User' or pretend to be 'User'. You only respond once as Assistant."

# Constants
LLaMA2_MODELS = {
    'LLaMA2-7B': LLaMA2_7B_ENDPOINT,
    'LLaMA2-13B': LLaMA2_13B_ENDPOINT,
    'LLaMA2-70B': LLaMA2_70B_ENDPOINT,
}

# Session State Variables
DEFAULT_TEMPERATURE = 0.1
DEFAULT_TOP_P = 0.9
DEFAULT_MAX_SEQ_LEN = 512
DEFAULT_PRE_PROMPT = PRE_PROMPT

def setup_session_state():
    st.session_state.setdefault('chat_dialogue', [])
    selected_model = st.sidebar.selectbox('Choose a LLaMA2 model:', list(LLaMA2_MODELS.keys()), key='model')
    st.session_state.setdefault('llm', LLaMA2_MODELS.get(selected_model, LLaMA2_70B_ENDPOINT))
    st.session_state.setdefault('temperature', DEFAULT_TEMPERATURE)
    st.session_state.setdefault('top_p', DEFAULT_TOP_P)
    st.session_state.setdefault('max_seq_len', DEFAULT_MAX_SEQ_LEN)
    st.session_state.setdefault('pre_prompt', DEFAULT_PRE_PROMPT)

def render_sidebar():
    st.session_state['temperature'] = st.sidebar.slider('Accuracy:', min_value=0.01, max_value=5.0, value=DEFAULT_TEMPERATURE, step=0.01)
    st.session_state['top_p'] = st.sidebar.slider('Top P:', min_value=0.01, max_value=1.0, value=DEFAULT_TOP_P, step=0.01)
    st.session_state['max_seq_len'] = st.sidebar.slider('Max Sequence Length:', min_value=64, max_value=4096, value=DEFAULT_MAX_SEQ_LEN, step=8)
    new_prompt = st.sidebar.text_area('Prompt before the chat starts. Edit here if desired:', DEFAULT_PRE_PROMPT)
    if new_prompt != DEFAULT_PRE_PROMPT and new_prompt != "" and new_prompt is not None:
        st.session_state['pre_prompt'] = new_prompt + "\n\n"
    else:
        st.session_state['pre_prompt'] = DEFAULT_PRE_PROMPT   

def render_chat_history():
    response_container = st.container()
    for message in st.session_state.chat_dialogue:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

def handle_user_input():
    user_input = st.chat_input("Type your question here to talk to LLaMA2")
    if user_input:
        st.session_state.chat_dialogue.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)

def generate_assistant_response():
    message_placeholder = st.empty()
    full_response = ""
    string_dialogue = st.session_state['pre_prompt']
    
    for dict_message in st.session_state.chat_dialogue:
        speaker = "User" if dict_message["role"] == "user" else "Assistant"
        string_dialogue += f"{speaker}: {dict_message['content']}\n\n"
    
    output = debounce_replicate_run(
        st.session_state['llm'],
        string_dialogue + "Assistant: ",
        st.session_state['max_seq_len'],
        st.session_state['temperature'],
        st.session_state['top_p'],
        REPLICATE_API_TOKEN
    )
    
    for item in output:
        full_response += item
        message_placeholder.markdown(full_response + "▌")
    
    message_placeholder.markdown(full_response)
    st.session_state.chat_dialogue.append({"role": "assistant", "content": full_response})

# Preprocessing
def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    return " ".join(text.split())

def load_embeddings():
    return joblib.load('news_embeddings.pkl')

news_embeddings = load_embeddings()

# Load models
try:
    vectorizer = joblib.load('tfidf_vectorizer.pkl')
    nn_model = joblib.load('nearest_neighbors_model.pkl')
    embedding_model = SentenceTransformer('models/all-MiniLM-L6-v2')
except Exception as e:
    st.error(f"Model loading failed: {e}")
    st.stop()

# TF-IDF based recommendation
def recommend_tfidf(title, top_n=5):
    clean_title = preprocess_text(title)
    match = process.extractOne(clean_title, news['headline'].tolist())[0]
    matched_article = news[news['headline'] == match].iloc[0]

    tfidf_vector = vectorizer.transform([match])
    _, indices = nn_model.kneighbors(tfidf_vector, n_neighbors=top_n + 1)
    recommended_articles = news.iloc[indices[0][1:]]
    return matched_article, recommended_articles

# Embedding-based recommendation
def recommend_embedding(title, top_n=5):
    query_vec = embedding_model.encode([title])
    similarities = cosine_similarity(query_vec, news_embeddings)[0]
    top_indices = np.argsort(similarities)[::-1]

    matched_index = top_indices[0]
    matched_article = news.iloc[matched_index]
    recommended_indices = top_indices[1:top_n + 1]
    recommended_articles = news.iloc[recommended_indices]
    return matched_article, recommended_articles

# Diversify by category
def diversify_by_category(matched_article, recommended_articles):
    matched_category = matched_article.get("category", None)
    if matched_category:
        diverse = news[news['category'] != matched_category]
        return diverse.sample(min(3, len(diverse)))  # up to 3 random different-category articles
    return recommended_articles

# Compute diversity score (based on category count)
def compute_diversity_score(df):
    diversity = df['category'].nunique() if 'category' in df else 0
    return diversity / len(df) if len(df) > 0 else 0


# Connect to DB
def connect_db():
    conn = sqlite3.connect("users.db")
    cursor = conn.cursor()
    return conn, cursor

# Create tables
def create_users_table():
    conn, cursor = connect_db()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            email TEXT,
            join_date TEXT
        )
    ''')
    conn.commit()
    conn.close()

# Register user
def register_user(username, password, email):
    conn, cursor = connect_db()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    if cursor.fetchone():
        return False
    join_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO users VALUES (?, ?, ?, ?)", (username, password, email, join_date))
    conn.commit()
    conn.close()
    return True

def save_liked_article(username, title, url):
    with open("liked_articles.csv", mode="a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([username, title, url, datetime.now().strftime("%Y-%m-%d %H:%M:%S")])

def save_favorite_article(username, title, url, description, image_url):
    with open("favorite_articles.csv", mode="a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([username, title, url, description, image_url, datetime.now().strftime("%Y-%m-%d %H:%M:%S")])

def load_liked_articles(username):
    liked = set()
    if os.path.exists("liked_articles.csv"):
        with open("liked_articles.csv", mode="r", encoding="utf-8") as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == username:
                    liked.add(row[1])
    return liked

def load_favorite_articles(username):
    favorites = []
    if os.path.exists("favorite_articles.csv"):
        with open("favorite_articles.csv", mode="r", encoding="utf-8") as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == username:
                    favorites.append({
                        "title": row[1],
                        "url": row[2],
                        "description": row[3],
                        "image_url": row[4]
                    })
    return favorites

def check_credentials(username, password):
    conn, cursor = connect_db()
    cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user is not None

def get_user_details(username):
    conn, cursor = connect_db()
    cursor.execute("SELECT username, email, join_date FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    conn.close()
    return user

def get_recommended_articles(all_articles, keyword_profile):
    recommendations = []
    for article in all_articles:
        title = article.get("title", "")
        description = article.get("description", "")
        article_text = title + " " + description
        score = sum(keyword_profile[word] for word in extract_keywords(article_text) if word in keyword_profile)
        if score > 0:
            recommendations.append((score, article))
    recommendations.sort(reverse=True, key=lambda x: x[0])
    return [article for score, article in recommendations]

def profile_page():
    st.title("👤 Your Profile")
    user = get_user_details(st.session_state.username)
    if user:
        st.write("### Username:", user[0])
        st.write("### Email:", user[1])
        st.write("### Joined On:", user[2])
    if st.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.rerun()

def login_page():
    st.title("🔐 Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        if check_credentials(username, password):
            st.session_state.logged_in = True
            st.session_state.username = username
            st.session_state.liked = load_liked_articles(username)
            st.session_state.favorites = load_favorite_articles(username)
            st.session_state.disliked = set()
            st.rerun()
        else:
            st.error("Invalid credentials")

def registration_page():
    st.title("📝 Register")
    username = st.text_input("Choose a Username")
    email = st.text_input("Your Email")
    password = st.text_input("Choose a Password", type="password")
    if st.button("Register"):
        if register_user(username, password, email):
            st.success("Registration successful! Please log in.")
            st.session_state.registered = True
            st.rerun()
        else:
            st.error("Username already taken")

def generate_safe_id(text):
    return re.sub(r'\W+', '_', text.lower())

def fetch_articles(category):
    API_KEY = "a7e38c01cbbf4a24a2ec91fa62417823"
    URL = "https://newsapi.org/v2/top-headlines"
    params = {"country": "us", "category": category.lower(), "apiKey": API_KEY, "pageSize": 10}
    res = requests.get(URL, params=params)
    return res.json().get("articles", []) if res.status_code == 200 else []

def extract_keywords(title):
    return set(re.findall(r'\b\w{5,}\b', title.lower()))

def is_similar(title1, title2):
    return len(extract_keywords(title1) & extract_keywords(title2)) > 1

def search_similar_articles(title):
    query = "+".join(title.split())
    url = f"https://www.bing.com/search?q={query}+site:news"
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        res = requests.get(url, headers=headers)
        links = re.findall(r'href="(https://[^"]+)"', res.text)
        return [link for link in links if "bing.com" not in link][:5]
    except Exception:
        return []
                                      
def feedback():
    # --- CUSTOM CSS ---
    st.markdown("""
        <style>
        .title {
            font-size:40px;
            font-weight:bold;
            color:#4CAF50;
            text-align:center;
            margin-bottom:20px;
        }
        .subheader {
            font-size:20px;
            text-align:center;
            color: #555;
        }
        .stTextInput>div>div>input {
            background-color: #f7f7f7;
            border-radius: 8px;
            padding: 10px;
        }
        .stTextArea>div>textarea {
            background-color: #f7f7f7;
            border-radius: 8px;
            padding: 10px;
        }
        </style>
    """, unsafe_allow_html=True)

    # --- HEADER ---
    st.markdown('<div class="title">📝 Feedback Form</div>', unsafe_allow_html=True)
    st.markdown('<div class="subheader">We’d love to hear your thoughts or suggestions!</div>', unsafe_allow_html=True)
    st.write("")

    # --- FORM ---
    with st.form("feedback_form", clear_on_submit=True):
        name = st.text_input("👤 Your Name")
        email = st.text_input("📧 Your Email")
        feedback_input = st.text_area("💬 Your Feedback", height=150)
        submit_button = st.form_submit_button("✅ Submit Feedback")

        if submit_button:
            if feedback_input.strip() == "":
                st.warning("⚠️ Please enter some feedback before submitting.")
            else:
                # Save to CSV
                feedback_data = {
                    "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "Name": name,
                    "Email": email,
                    "Feedback": feedback_input
                }

                file_path = "feedback.csv"
                if os.path.exists(file_path):
                    df = pd.read_csv(file_path)
                    df = pd.concat([df, pd.DataFrame([feedback_data])], ignore_index=True)
                else:
                    df = pd.DataFrame([feedback_data])
                df.to_csv(file_path, index=False)

                st.success("🎉 Thank you for your feedback!")

    # --- FOOTER ---
    st.markdown("---")
    

def news_page():
    st.title("📰 Personalized News Recommender")

    title_input = st.text_input("🔍 Enter a news headline:")
    method = st.radio("Choose recommendation method:", ["TF-IDF", "Sentence Embedding"])
    challenge_mode = st.checkbox("🎯 Challenge my perspective (show opposing views)")
    show_diversity = st.checkbox("📊 Show diversity score")
    explore_mode = st.checkbox("🌍 Surprise me with something different")

    if title_input:
        with st.spinner("Fetching recommendations..."):
            if method == "TF-IDF":
                matched_article, recommended_articles = recommend_tfidf(title_input)
            else:
                matched_article, recommended_articles = recommend_embedding(title_input)
                
            # Optionally diversify 
            if challenge_mode:
                recommended_articles = diversify_by_category(matched_article, recommended_articles)

            # Diversity score
            diversity_score = compute_diversity_score(recommended_articles)

        st.subheader("📰 Matched Article")
        st.markdown(f"**Headline:** {matched_article['headline']}")
        st.markdown(f"**Description:** {matched_article['short_description']}")   
        if 'category' in matched_article:
            st.markdown(f"**Category:** {matched_article['category']}")
        if 'source' in matched_article:
            st.markdown(f"**Source:** {matched_article['source']}")
        
        st.subheader("🔁 Recommended Articles")
        if show_diversity:   
            st.markdown(f"📊 **Diversity Score:** `{diversity_score:.2f}`")

        for idx, row in recommended_articles.iterrows():
            st.markdown(f"### {row['headline']}")
            if 'image' in row and pd.notnull(row['image']):
                st.image(row['image'], width=600)
            if 'short_description' in row and pd.notnull(row['short_description']):
                st.write(row['short_description'])
            if 'category' in row and pd.notnull(row['category']):
                st.markdown(f"*Category: {row['category']}*")
            if 'source' in row and pd.notnull(row['source']):
                st.markdown(f"*Source: {row['source']}*")
            if 'link' in row and pd.notnull(row['link']):
                st.markdown(f"[🔗 Read full article]({row['link']})", unsafe_allow_html=True)
            st.markdown("---")

    setup_session_state()
    render_chat_history()
    handle_user_input()
    generate_assistant_response()        

    # Out-of-bubble explorer
    if explore_mode:
        st.subheader("🌐 Explore Outside Your Bubble")
        explore_article = news.sample(1).iloc[0]
        st.markdown(f"### {explore_article['headline']}")
        st.write(explore_article.get('short_description', ''))
        if 'image' in explore_article and pd.notnull(explore_article['image']):
            st.image(explore_article['image'], width=600)
        if 'link' in explore_article and pd.notnull(explore_article['link']):
            st.markdown(f"[🔗 Read full article]({explore_article['link']})", unsafe_allow_html=True)
                                               
    categories = ["Technology", "Sports", "Business", "Entertainment", "Health", "Science", "General"]
    selected = st.multiselect("Choose categories:", categories, default=["Technology"])
    show_favorites = st.checkbox("⭐ Show Favorites")
    show_similar = st.checkbox("🔍 Show Similar Articles")
    
    if show_favorites and st.session_state.favorites:
        st.subheader("⭐ Your Favorites")
        for fav in st.session_state.favorites:
            st.markdown(f"### [{fav['title']}]({fav['url']})")
            if fav.get("image_url"):
                st.image(fav["image_url"], width=600)
            st.markdown(f"_{fav['description']}_")
            if show_similar:
                links = search_similar_articles(fav["title"])
                st.markdown("**Related:**")
                for l in links:
                    st.markdown(f"- [{l}]({l})")
            st.markdown("---")

    for category in selected:
        for article in fetch_articles(category):
            title = article["title"]
            if title in st.session_state.disliked:
                continue

            safe_id = generate_safe_id(title)
            st.markdown(f"## {title}")
            if article.get("urlToImage"):
                st.image(article["urlToImage"], width=600)
            st.markdown(f"_{article.get('description', '')}_")
            st.markdown(f"[Read more ➡️]({article['url']})")

            col1, col2 = st.columns(2)
            with col1:
                liked = title in st.session_state.liked
                if st.button(f"{'❤️' if liked else '🤍'} Like", key=f"like_{safe_id}"):
                    if liked:
                        st.session_state.liked.remove(title)
                    else:
                        st.session_state.liked.add(title)
                        save_liked_article(st.session_state.username, title, article["url"])
            with col2:
                if st.button("⭐ Favorite", key=f"fav_{safe_id}"):
                    if not any(f["title"] == title for f in st.session_state.favorites):
                        fav_obj = {
                            "title": title,
                            "url": article["url"],
                            "description": article.get("description", ""),
                            "image_url": article.get("urlToImage", "")
                        }
                        st.session_state.favorites.append(fav_obj)
                        save_favorite_article(st.session_state.username, **fav_obj)
                        st.success("Added to favorites")
            st.markdown("---")

# Main App Logic
def main():

    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.session_state.liked = set()
        st.session_state.favorites = []
        st.session_state.disliked = set()

    create_users_table()

    if not st.session_state.logged_in:
        choice = st.sidebar.selectbox("Choose an option", ["Login", "Register"])
        if choice == "Login":
            login_page()
        else:
            registration_page()
    else:
        st.sidebar.title(f"Welcome, {st.session_state.username}")
        page = st.sidebar.radio("Navigate", ["News Feed", "Profile", "Feedback"])
        if page == "News Feed":
            news_page()
        elif page == "Profile":  
            profile_page()    
        else:
            feedback()
            
if __name__ == "__main__":
    main()
